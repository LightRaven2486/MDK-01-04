﻿using System.Management;

ManagementScope scope = new ManagementScope("\\\\.\\ROOT\\WMI");

ObjectQuery query = new ObjectQuery("SELECT * FROM MS_SystemInformation");

ManagementObjectSearcher searcher = new ManagementObjectSearcher(scope, query);

ManagementObjectCollection collection = searcher.Get();

foreach (ManagementObject item in collection)
{
    Console.WriteLine(String.Format("|{0,30}|", $"Версия системы: {item.GetPropertyValue("SystemVersion")}"));
    Console.WriteLine(String.Format("|{0,20}|", $"Версия биос: {item.GetPropertyValue("BIOSVersion")}"));
    Console.WriteLine(String.Format("|{0,20}|", $"Активна ли система: {item.GetPropertyValue("Active")}"));
    Console.WriteLine(String.Format("|{0,20}|", $"Представитель биос: {item.GetPropertyValue("BIOSVendor")}"));

}

ObjectQuery query2 = new ObjectQuery("SELECT * FROM Win32_Process");

ManagementObjectSearcher searcher2 = new ManagementObjectSearcher(query2);

ManagementObjectCollection collection2 = searcher2.Get();

Console.WriteLine();

foreach (ManagementObject item in collection2)
{
    Console.WriteLine(String.Format("|{0,30}|", $"{item.GetPropertyValue("ProcessId")}"));
}

ObjectQuery query3 = new ObjectQuery("SELECT * FROM Win32_OperatingSystem");

ManagementObjectSearcher searcher3 = new ManagementObjectSearcher(query3);

ManagementObjectCollection collection3 = searcher3.Get();

Console.WriteLine();

foreach (ManagementObject item in collection3)
{
    Console.WriteLine(String.Format("|{0,30}|", $"Дебаг: {item.GetPropertyValue("Debug")}"));
}

ObjectQuery query4 = new ObjectQuery("SELECT * FROM Win32_Service");

ManagementObjectSearcher searcher4 = new ManagementObjectSearcher(query4);

ManagementObjectCollection collection4 = searcher4.Get();

Console.WriteLine();

foreach (ManagementObject item in collection4)
{
    Console.WriteLine(String.Format("|{0,30}||{0,20}|", $"Запуск сервисов: {item.GetPropertyValue("StartName")}",item.GetPropertyValue("StartMode")));
}
